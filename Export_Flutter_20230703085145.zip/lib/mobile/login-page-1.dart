import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // loginpage1msX (35:119)
        width: double.infinity,
        height: 640*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/mobile/images/vector-4-tpq.png',
            ),
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              // ors9s (35:123)
              left: 176*fem,
              top: 536*fem,
              child: Align(
                child: SizedBox(
                  width: 11*fem,
                  height: 15*fem,
                  child: Text(
                    'or',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame1YWu (35:124)
              left: 158*fem,
              top: 495*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 47*fem,
                  height: 30*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff27014a),
                    borderRadius: BorderRadius.circular(7*fem),
                  ),
                  child: Center(
                    child: Text(
                      'Login',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 12*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.1725*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // signupoBw (35:126)
              left: 163*fem,
              top: 586*fem,
              child: Align(
                child: SizedBox(
                  width: 38*fem,
                  height: 15*fem,
                  child: Text(
                    'Signup',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff023768),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // wanttocreateanaccountVKf (35:127)
              left: 114*fem,
              top: 561*fem,
              child: Align(
                child: SizedBox(
                  width: 146*fem,
                  height: 15*fem,
                  child: Text(
                    'Want to create an account?',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group8ac1 (35:138)
              left: 8*fem,
              top: 11*fem,
              child: Align(
                child: SizedBox(
                  width: 20*fem,
                  height: 60*fem,
                  child: Image.asset(
                    'assets/mobile/images/group-8-241.png',
                    width: 20*fem,
                    height: 60*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // group11HFX (35:143)
              left: 18*fem,
              top: 242*fem,
              child: Container(
                width: 310*fem,
                height: 130*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // autogroup2fahoDs (Ly4LjH1teJjsPwDpKY2Fah)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 0*fem),
                      width: 42*fem,
                      height: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogrouppnvdWe5 (Ly4LrBz3CPoXeCgPwhPNvD)
                            margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 4*fem, 47.59*fem),
                            padding: EdgeInsets.fromLTRB(3*fem, 2.32*fem, 3*fem, 2.32*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/mobile/images/ellipse-9.png',
                                ),
                              ),
                            ),
                            child: Center(
                              // icons8user641cBK (35:156)
                              child: SizedBox(
                                width: 26*fem,
                                height: 32.5*fem,
                                child: Image.asset(
                                  'assets/mobile/images/icons8-user-64-1.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // autogroupxwtxLd7 (Ly4LurYbgasZkNGkZdxwTX)
                            width: double.infinity,
                            height: 45.27*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // ellipse116MP (35:152)
                                  left: 6*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 32*fem,
                                      height: 37.14*fem,
                                      child: Image.asset(
                                        'assets/mobile/images/ellipse-11.png',
                                        width: 32*fem,
                                        height: 37.14*fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // ellipse10c4q (35:153)
                                  left: 5*fem,
                                  top: 3.4821472168*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 32*fem,
                                      height: 37.14*fem,
                                      child: Image.asset(
                                        'assets/mobile/images/ellipse-10.png',
                                        width: 32*fem,
                                        height: 37.14*fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // icons8password1001XBo (35:155)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 42*fem,
                                      height: 45.27*fem,
                                      child: Image.asset(
                                        'assets/mobile/images/icons8-password-100-1-xdX.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // logicqyB (35:144)
                      margin: EdgeInsets.fromLTRB(0*fem, 1.16*fem, 0*fem, 0*fem),
                      width: 253*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(7*fem),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroup7w69mrq (Ly4MFG9voWDczZXGfR7w69)
                            margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 52.23*fem),
                            padding: EdgeInsets.fromLTRB(15*fem, 10.45*fem, 15*fem, 10.54*fem),
                            width: 252*fem,
                            decoration: BoxDecoration (
                              color: Color(0xfff8f7f7),
                              borderRadius: BorderRadius.circular(7*fem),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x3f000000),
                                  offset: Offset(0*fem, 4*fem),
                                  blurRadius: 2*fem,
                                ),
                              ],
                            ),
                            child: Text(
                              'Name',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 12*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.1725*ffem/fem,
                                color: Color(0xff797979),
                              ),
                            ),
                          ),
                          Container(
                            // autogrouphvdtcMf (Ly4MJviVHhHf6j7dHMhVdT)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                            padding: EdgeInsets.fromLTRB(17*fem, 8.13*fem, 5*fem, 8.13*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xfff8f7f7),
                              borderRadius: BorderRadius.circular(7*fem),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x3f000000),
                                  offset: Offset(0*fem, 4*fem),
                                  blurRadius: 2*fem,
                                ),
                              ],
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // passwordg6d (35:150)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 156*fem, 0.09*fem),
                                  child: Text(
                                    'Password',
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.1725*ffem/fem,
                                      color: Color(0xff797979),
                                    ),
                                  ),
                                ),
                                Container(
                                  // icons8showpassword321zND (35:157)
                                  width: 21*fem,
                                  height: 19.73*fem,
                                  child: Image.asset(
                                    'assets/mobile/images/icons8-show-password-32-1-Nob.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // forgotpasswordvmf (19:55)
              left: 226*fem,
              top: 372*fem,
              child: Align(
                child: SizedBox(
                  width: 96*fem,
                  height: 15*fem,
                  child: Text(
                    'Forgot password?',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // loginc8h (502:2)
              left: 154*fem,
              top: 110*fem,
              child: Align(
                child: SizedBox(
                  width: 52*fem,
                  height: 22*fem,
                  child: Text(
                    'LOGIN',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 18*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}
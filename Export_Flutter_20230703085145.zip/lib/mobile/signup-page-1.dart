import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // signuppage1aFT (19:71)
        width: double.infinity,
        height: 640*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/mobile/images/vector-4.png',
            ),
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              // createaccountzTb (19:73)
              left: 98*fem,
              top: 127*fem,
              child: Align(
                child: SizedBox(
                  width: 153*fem,
                  height: 22*fem,
                  child: Text(
                    'CREATE ACCOUNT',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 18*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // orQXK (19:75)
              left: 174*fem,
              top: 542*fem,
              child: Align(
                child: SizedBox(
                  width: 11*fem,
                  height: 15*fem,
                  child: Text(
                    'or',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // frame1UGH (19:83)
              left: 152*fem,
              top: 496*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 54*fem,
                  height: 30*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff27014a),
                    borderRadius: BorderRadius.circular(7*fem),
                  ),
                  child: Center(
                    child: Text(
                      'Signup',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 12*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.1725*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // login6YZ (19:85)
              left: 167*fem,
              top: 602*fem,
              child: Align(
                child: SizedBox(
                  width: 31*fem,
                  height: 15*fem,
                  child: Text(
                    'Login',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff023768),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // alreadyhaveanaccountPnZ (19:86)
              left: 114*fem,
              top: 572*fem,
              child: Align(
                child: SizedBox(
                  width: 136*fem,
                  height: 15*fem,
                  child: Text(
                    'Already have an account?',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.1725*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group8JPj (35:11)
              left: 8*fem,
              top: 11*fem,
              child: Align(
                child: SizedBox(
                  width: 20*fem,
                  height: 60*fem,
                  child: Image.asset(
                    'assets/mobile/images/group-8.png',
                    width: 20*fem,
                    height: 60*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // group11oLV (35:26)
              left: 18*fem,
              top: 234*fem,
              child: Container(
                width: 309*fem,
                height: 176*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // autogrouprsfpVUD (Ly4K5pkwSRhZSovvMyrsFP)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 0*fem),
                      width: 42*fem,
                      height: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupr1w1CNd (Ly4KW4ZZ1xjD6x1N1KR1W1)
                            padding: EdgeInsets.fromLTRB(5*fem, 0*fem, 5*fem, 32*fem),
                            width: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                ClipRect(
                                  // autogroupdze1yXo (Ly4KFZyhe7gRs7XbNeDZe1)
                                  child: BackdropFilter(
                                    filter: ImageFilter.blur (
                                      sigmaX: 2*fem,
                                      sigmaY: 2*fem,
                                    ),
                                    child: Container(
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 41*fem),
                                      padding: EdgeInsets.fromLTRB(3*fem, 2*fem, 3*fem, 2*fem),
                                      width: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                        borderRadius: BorderRadius.circular(16*fem),
                                      ),
                                      child: Center(
                                        // icons8user641TSy (35:39)
                                        child: SizedBox(
                                          width: 26*fem,
                                          height: 28*fem,
                                          child: Image.asset(
                                            'assets/mobile/images/icons8-user-64-1-i7K.png',
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                ClipRect(
                                  // autogrouprjrvPbX (Ly4KLjVmEZpkei8pcNrJrV)
                                  child: BackdropFilter(
                                    filter: ImageFilter.blur (
                                      sigmaX: 2*fem,
                                      sigmaY: 2*fem,
                                    ),
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(6*fem, 7*fem, 6*fem, 8*fem),
                                      width: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0xffffffff),
                                        borderRadius: BorderRadius.circular(16*fem),
                                      ),
                                      child: Center(
                                        // email1Uss (35:37)
                                        child: SizedBox(
                                          width: 20*fem,
                                          height: 17*fem,
                                          child: Image.asset(
                                            'assets/mobile/images/email-1.png',
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupzgyr2eV (Ly4KQUtX1DWUMHg19rzGYR)
                            width: double.infinity,
                            height: 39*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // ellipse10aAD (35:36)
                                  left: 5*fem,
                                  top: 3*fem,
                                  child: ClipRect(
                                    child: BackdropFilter(
                                      filter: ImageFilter.blur (
                                        sigmaX: 2*fem,
                                        sigmaY: 2*fem,
                                      ),
                                      child: Align(
                                        child: SizedBox(
                                          width: 32*fem,
                                          height: 32*fem,
                                          child: Container(
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(16*fem),
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // icons8password1001Tzh (35:38)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 42*fem,
                                      height: 39*fem,
                                      child: Image.asset(
                                        'assets/mobile/images/icons8-password-100-1.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // logicnn5 (35:27)
                      margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                      width: 252*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(7*fem),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupdceuubo (Ly4KpyBiS8PAnfavZqDcEu)
                            padding: EdgeInsets.fromLTRB(15*fem, 9*fem, 15*fem, 7*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xfff8f7f7),
                              borderRadius: BorderRadius.circular(7*fem),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x3f000000),
                                  offset: Offset(0*fem, 4*fem),
                                  blurRadius: 2*fem,
                                ),
                              ],
                            ),
                            child: Text(
                              'Name',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 12*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.1725*ffem/fem,
                                color: Color(0xff797979),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 39*fem,
                          ),
                          Container(
                            // autogroupemcvLSD (Ly4KvYrkSsbuYKvHRHeMCV)
                            padding: EdgeInsets.fromLTRB(15*fem, 9*fem, 15*fem, 7*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xfff8f7f7),
                              borderRadius: BorderRadius.circular(7*fem),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x3f000000),
                                  offset: Offset(0*fem, 4*fem),
                                  blurRadius: 2*fem,
                                ),
                              ],
                            ),
                            child: Text(
                              'Email',
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 12*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.1725*ffem/fem,
                                color: Color(0xff797979),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 39*fem,
                          ),
                          Container(
                            // autogroupgfysyzy (Ly4L3iKUrLWcZqDLp5gfys)
                            padding: EdgeInsets.fromLTRB(15*fem, 7*fem, 5*fem, 7*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xfff8f7f7),
                              borderRadius: BorderRadius.circular(7*fem),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x3f000000),
                                  offset: Offset(0*fem, 4*fem),
                                  blurRadius: 2*fem,
                                ),
                              ],
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // passwordGz5 (35:33)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 158*fem, 0*fem),
                                  child: Text(
                                    'Password',
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.1725*ffem/fem,
                                      color: Color(0xff797979),
                                    ),
                                  ),
                                ),
                                Container(
                                  // icons8showpassword321bWZ (35:40)
                                  width: 21*fem,
                                  height: 17*fem,
                                  child: Image.asset(
                                    'assets/mobile/images/icons8-show-password-32-1.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}
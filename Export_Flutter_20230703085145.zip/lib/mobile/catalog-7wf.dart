import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // catalogc7K (503:31)
        padding: EdgeInsets.fromLTRB(8*fem, 11*fem, 8*fem, 74*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/mobile/images/vector-4-iMP.png',
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group8WiV (503:33)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 324*fem, 13*fem),
              width: 20*fem,
              height: 60*fem,
              child: Image.asset(
                'assets/mobile/images/group-8-RcM.png',
                width: 20*fem,
                height: 60*fem,
              ),
            ),
            Container(
              // productsEeV (503:38)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 26*fem),
              child: Text(
                'PRODUCTS',
                style: SafeGoogleFont (
                  'Roboto',
                  fontSize: 18*ffem,
                  fontWeight: FontWeight.w500,
                  height: 1.1725*ffem/fem,
                  color: Color(0xff000000),
                ),
              ),
            ),
            Container(
              // image2ksj (503:45)
              width: 286*fem,
              height: 434*fem,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(37*fem),
                child: Image.asset(
                  'assets/mobile/images/image-2.png',
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}
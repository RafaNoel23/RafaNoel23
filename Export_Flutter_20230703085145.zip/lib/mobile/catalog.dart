import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // catalogT29 (502:3)
        padding: EdgeInsets.fromLTRB(8*fem, 11*fem, 8*fem, 29*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/mobile/images/vector-4-Moo.png',
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group8jVT (502:10)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 324*fem, 13*fem),
              width: 20*fem,
              height: 60*fem,
              child: Image.asset(
                'assets/mobile/images/group-8-rXB.png',
                width: 20*fem,
                height: 60*fem,
              ),
            ),
            Container(
              // laptopse6d (502:28)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 13*fem),
              child: Text(
                'PRODUCTS',
                style: SafeGoogleFont (
                  'Roboto',
                  fontSize: 18*ffem,
                  fontWeight: FontWeight.w500,
                  height: 1.1725*ffem/fem,
                  color: Color(0xff000000),
                ),
              ),
            ),
            Container(
              // image19ZB (503:30)
              margin: EdgeInsets.fromLTRB(14*fem, 0*fem, 0*fem, 21*fem),
              width: 286*fem,
              height: 441*fem,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(26*fem),
                child: Image.asset(
                  'assets/mobile/images/image-1.png',
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Container(
              // frame1rTb (504:48)
              margin: EdgeInsets.fromLTRB(140*fem, 0*fem, 141*fem, 0*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: double.infinity,
                  height: 30*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff27014a),
                    borderRadius: BorderRadius.circular(7*fem),
                  ),
                  child: Center(
                    child: Text(
                      'BOARDS',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 12*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.1725*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}
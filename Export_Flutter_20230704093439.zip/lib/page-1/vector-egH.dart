import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 279.7537231445;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // vectorrBK (0:342)
        width: double.infinity,
        height: 2.94*fem,
        child: Image.asset(
          'assets/page-1/images/vector-LLZ.png',
          width: 279.75*fem,
          height: 2.94*fem,
        ),
      ),
          );
  }
}
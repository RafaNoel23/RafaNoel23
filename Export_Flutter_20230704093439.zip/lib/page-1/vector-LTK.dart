import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 63.6936035156;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // vector7b7 (0:320)
        width: double.infinity,
        height: 17.92*fem,
        child: Image.asset(
          'assets/page-1/images/vector-daq.png',
          width: 63.69*fem,
          height: 17.92*fem,
        ),
      ),
          );
  }
}
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 156.25;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // vector8B3 (0:24)
        width: double.infinity,
        height: 338.33*fem,
        child: Image.asset(
          'assets/page-1/images/vector-4Tj.png',
          width: 156.25*fem,
          height: 338.33*fem,
        ),
      ),
          );
  }
}
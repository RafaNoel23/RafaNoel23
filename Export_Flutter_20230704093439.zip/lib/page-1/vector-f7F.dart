import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 304.2921142578;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // vectorAJ5 (1:13)
        width: double.infinity,
        height: 658.89*fem,
        child: Image.asset(
          'assets/page-1/images/vector-BgV.png',
          width: 304.29*fem,
          height: 658.89*fem,
        ),
      ),
          );
  }
}
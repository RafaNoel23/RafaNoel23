import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/page-1/vector.dart';
// import 'package:myapp/page-1/vector-nP3.dart';
// import 'package:myapp/page-1/vector-wBP.dart';
// import 'package:myapp/page-1/vector-x8R.dart';
// import 'package:myapp/page-1/vector-AnD.dart';
// import 'package:myapp/page-1/vector-N9X.dart';
// import 'package:myapp/page-1/vector-nFB.dart';
// import 'package:myapp/page-1/vector-dHj.dart';
// import 'package:myapp/page-1/vector-4fs.dart';
// import 'package:myapp/page-1/vector-Rwf.dart';
// import 'package:myapp/page-1/vector-f7F.dart';
// import 'package:myapp/page-1/vector-5ih.dart';
// import 'package:myapp/page-1/vector-ujf.dart';
// import 'package:myapp/page-1/vector-MtV.dart';
// import 'package:myapp/page-1/vector-XM3.dart';
// import 'package:myapp/page-1/vector-BCd.dart';
// import 'package:myapp/page-1/vector-dsF.dart';
// import 'package:myapp/page-1/vector-gMf.dart';
// import 'package:myapp/page-1/vector-KxM.dart';
// import 'package:myapp/page-1/vector-C2V.dart';
// import 'package:myapp/page-1/vector-TW9.dart';
// import 'package:myapp/page-1/vector-88R.dart';
// import 'package:myapp/page-1/vector-Pc5.dart';
// import 'package:myapp/page-1/vector-4EM.dart';
// import 'package:myapp/page-1/vector-Huj.dart';
// import 'package:myapp/page-1/vector-xH7.dart';
// import 'package:myapp/page-1/vector-xyF.dart';
// import 'package:myapp/page-1/vector-KDT.dart';
// import 'package:myapp/page-1/vector-PFF.dart';
// import 'package:myapp/page-1/vector-qQ5.dart';
// import 'package:myapp/page-1/vector-uRs.dart';
// import 'package:myapp/page-1/vector-yyT.dart';
// import 'package:myapp/page-1/vector-e5w.dart';
// import 'package:myapp/page-1/vector-tH7.dart';
// import 'package:myapp/page-1/vector-ujw.dart';
// import 'package:myapp/page-1/vector-Mds.dart';
// import 'package:myapp/page-1/vector-bq3.dart';
// import 'package:myapp/page-1/vector-FAq.dart';
// import 'package:myapp/page-1/vector-uHK.dart';
// import 'package:myapp/page-1/vector-9jP.dart';
// import 'package:myapp/page-1/vector-p6m.dart';
// import 'package:myapp/page-1/vector-ff7.dart';
// import 'package:myapp/page-1/vector-ifK.dart';
// import 'package:myapp/page-1/vector-voK.dart';
// import 'package:myapp/page-1/vector-xG9.dart';
// import 'package:myapp/page-1/vector-Djo.dart';
// import 'package:myapp/page-1/vector-rZo.dart';
// import 'package:myapp/page-1/vector-Hww.dart';
// import 'package:myapp/page-1/vector-vX3.dart';
// import 'package:myapp/page-1/vector-Ay7.dart';
// import 'package:myapp/page-1/vector-2nM.dart';
// import 'package:myapp/page-1/vector-HVK.dart';
// import 'package:myapp/page-1/vector-kQq.dart';
// import 'package:myapp/page-1/vector-zru.dart';
// import 'package:myapp/page-1/vector-Skq.dart';
// import 'package:myapp/page-1/vector-78D.dart';
// import 'package:myapp/page-1/vector-YmF.dart';
// import 'package:myapp/page-1/vector-DeR.dart';
// import 'package:myapp/page-1/vector-fHT.dart';
// import 'package:myapp/page-1/vector-h1B.dart';
// import 'package:myapp/page-1/vector-65F.dart';
// import 'package:myapp/page-1/vector-XyB.dart';
// import 'package:myapp/page-1/vector-P1j.dart';
// import 'package:myapp/page-1/vector-F5s.dart';
// import 'package:myapp/page-1/vector-uTF.dart';
// import 'package:myapp/page-1/vector-9PX.dart';
// import 'package:myapp/page-1/vector-1Tf.dart';
// import 'package:myapp/page-1/vector-Uty.dart';
// import 'package:myapp/page-1/vector-LTK.dart';
// import 'package:myapp/page-1/vector-Nwj.dart';
// import 'package:myapp/page-1/vector-egH.dart';
// import 'package:myapp/page-1/vector-iCH.dart';
// import 'package:myapp/page-1/vector-yR3.dart';
// import 'package:myapp/page-1/vector-QoB.dart';
// import 'package:myapp/page-1/vector-5AZ.dart';
// import 'package:myapp/page-1/vector-X4V.dart';
// import 'package:myapp/page-1/vector-Av5.dart';
// import 'package:myapp/page-1/vector-1bF.dart';
// import 'package:myapp/page-1/vector-Dz9.dart';
// import 'package:myapp/page-1/vector-64H.dart';
// import 'package:myapp/page-1/vector-kwT.dart';
// import 'package:myapp/page-1/vector-pyF.dart';
// import 'package:myapp/page-1/vector-syT.dart';
// import 'package:myapp/page-1/vector-wVT.dart';
// import 'package:myapp/page-1/vector-oJh.dart';
// import 'package:myapp/page-1/vector-f7w.dart';
// import 'package:myapp/page-1/vector-vrV.dart';
// import 'package:myapp/page-1/vector-z7b.dart';
// import 'package:myapp/page-1/vector-ezm.dart';
// import 'package:myapp/page-1/vector-A7s.dart';
// import 'package:myapp/page-1/vector-bW1.dart';
// import 'package:myapp/page-1/vector-zKB.dart';
// import 'package:myapp/page-1/vector-465.dart';
// import 'package:myapp/page-1/image-1.dart';
// import 'package:myapp/page-1/image-2.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
	@override
	Widget build(BuildContext context) {
	return MaterialApp(
		title: 'Flutter',
		debugShowCheckedModeBanner: false,
		scrollBehavior: MyCustomScrollBehavior(),
		theme: ThemeData(
		primarySwatch: Colors.blue,
		),
		home: Scaffold(
		body: SingleChildScrollView(
			child: Scene(),
		),
		),
	);
	}
}
